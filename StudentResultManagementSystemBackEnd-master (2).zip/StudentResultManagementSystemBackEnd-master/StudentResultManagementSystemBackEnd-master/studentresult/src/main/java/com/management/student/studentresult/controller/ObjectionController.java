package com.management.student.studentresult.controller;

public class ObjectionController {
}
